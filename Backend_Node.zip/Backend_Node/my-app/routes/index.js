var express = require('express');
var router = express.Router();
const EventsController = require('../public/EventsController');
// const mongoose = require('mongoose')

// const connectDB = async()=>{
//   mongoose.connect('mongodb://localhost:27017/Doctor_App');
//   const productSchema = new mongoose.Schema({});
//   const product = mongoose.model('product', productSchema)
//   const data = await product.find();
//   console.log("Akhilesh",data)
// }
// connectDB()
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.post('/send-email', EventsController.getEmailSuggestion);

module.exports = router;
