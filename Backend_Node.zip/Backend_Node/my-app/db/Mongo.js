const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');

const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// MongoDB Connection URI
const uri = 'mongodb://localhost:27017';

// Database Name
const dbName = 'Doctor_Appointment';

// Create a new MongoClient
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });

// Function to connect to MongoDB
async function connectDB() {
  try {
    // Connect the client to the server
    await client.connect();
    console.log('Connected to MongoDB');
  } catch (err) {
    console.error('Error connecting to MongoDB:', err);
  }
}

// Define route for signup
app.post('/signup', async (req, res) => {
    const db = client.db(dbName);
    const collection = db.collection('Users');
  
    try {
      // Extract data from request body
      const { name, email, password } = req.body;
  
      // Insert data into the database
      const result = await collection.insertOne({ name, email, password });
      
      // Respond with success message
      res.status(201).json({ message: 'User signed up successfully', userId: result.insertedId });
    } catch (err) {
      console.error('Error signing up user:', err);
      res.status(500).json({ error: 'An error occurred while signing up user' });
    }
  });
  
  // Start the server
  app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });

// Call the function to connect to MongoDB
connectDB();
module.exports = { connectDB };
